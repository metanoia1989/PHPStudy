<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:102:"E:\WorkSpace\PHPStudy\ChatIM\CustomerServiceSystem\public/../application/platform\view\app\subapp.html";i:1600917847;s:106:"E:\WorkSpace\PHPStudy\ChatIM\CustomerServiceSystem\public/../application/platform\view\layout\default.html";i:1600917847;s:103:"E:\WorkSpace\PHPStudy\ChatIM\CustomerServiceSystem\public/../application/platform\view\common\meta.html";i:1600917847;s:105:"E:\WorkSpace\PHPStudy\ChatIM\CustomerServiceSystem\public/../application/platform\view\common\script.html";i:1600917847;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
<link rel="shortcut icon" href="/dianqilai.ico">
<title><?php echo !empty($title)?$title.'-':null; ?><?php echo !empty($option['title'])?$option['title']:'禾匠信息科技'; ?></title>
<link rel="stylesheet" href="https://at.alicdn.com/t/font_353057_c9nwwwd9rt7.css">
<link href="//at.alicdn.com/t/font_353057_iozwthlolt.css" rel="stylesheet">


<link rel="stylesheet" type="text/css" href="__style__/platform/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="__style__/platform/common.css" />
<link rel="stylesheet" type="text/css" href="__style__/platform/common.v2.css" />
<link rel="stylesheet" type="text/css" href="__style__/platform/flex.css" />

<script>var _upload_url = "<?php echo url('upload/file'); ?>";</script>
<script type="text/javascript" src="__script__/platform/vue.js"></script>
<script type="text/javascript" src="__script__/platform/jquery.min.js"></script>
<script type="text/javascript" src="__script__/platform/popper.min.js"></script>
<script type="text/javascript" src="__script__/platform/bootstrap.min.js"></script>
<script type="text/javascript" src="__script__/platform/common.js"></script>
<script type="text/javascript" src="__script__/platform/common.v2.js"></script>
<script type="text/javascript" src="__script__/platform/plupload.full.min.js"></script>
        <style>
            .navbar {
                height: 200px;
                color: #fff;
                font-size: 18px;
                position: relative;
                background-image: url("__image__/admin/A/BG-B.png");
            }

            .nav-top {
                position: absolute;
                top: 10px;
                left: 0;
                right: 0;
            }

            .navbar-nav .nav-link {
                color: #fff;
                font-size: 16px;
            }

            .dropdown-menu.show {
                display: inline-block;
            }

            .navbar-nav .dropdown-menu {
                position: absolute;
                background-color: #262760;
                border-radius: 10px;
            }

            .navbar-nav .dropdown-menu a {
                color: #fff;
            }

            .dropdown-item {
                height: 40px;
                line-height: 40px;
                padding: 0 0 0 20px;
                font-size: 12px;
            }

            .dropdown-item:hover {
                background-color: #1D1840;
            }

            .nav-text {
                padding-left: 36.5px;
                font-size: 22px;
            }

            .navbar .nav-menu {
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                justify-content: flex-start;
                font-size: 14px;
                height: 35px;
            }

            .menu-item {
                float: left;
                margin-right: 40px;
                height: 35px;
                cursor: pointer;
            }

            .menu-item:first-of-type {
                padding-left: 16.5px;
            }

            .menu-item.active {
                color: #3399FF;
                border-bottom: 2px solid #3399FF;
            }

            .child-menu {
                background-color: #fff;
                border-radius: 8px;
                height: 65px;
                padding: 16.5px 20px;
                margin-bottom: 10px;
                display: none;
            }

            .child-menu a {
                color: #999999;
                display: inline-block;
                height: 32px;
                line-height: 32px;
                padding: 0 12px;
                text-decoration: none;
            }

            .child-menu .active {
                color: #3399ff;
                background-color: #F5FAFF;
                border-radius: 16px;
            }

            .change-password-modal .modal-dialog {
                margin-top: 15%;
                max-width: 600px;
            }

            .change-password-modal .modal-dialog .modal-content {
                width: 600px;
                border-radius: 8px;
            }

            .change-password-modal .modal-header {
                padding: 0 24px;
                height: 56px;
                line-height: 56px;
                border-bottom: 1px solid #f7f7f7;
            }

            .change-password-modal .modal-title {
                font-size: 13px;
                color: #555555;
            }

            .form-input .form-control {
                width: 300px;
                padding-left: 16px;
                border-radius: 8px;
                height: 36px;
                border: 1px solid #e5e3e9;
            }

            .change-password-modal .modal-body {
                padding: 24px 0;
            }

            .col-form-label {
                padding: 0;
                width: 160px;
                height: 36px;
                line-height: 36px;
                text-align: right;
                margin-right: 32px;
                float: left;
                font-size: 13px;
                color: #999999;
            }

            label.required::before {
                content: '';
                background-color: #ff5c5c;
                width: 6px;
                height: 6px;
                border-radius: 6px;
                top: 14px;
                left: 105px;
            }

            label.check::before {
                left: 90px;
            }

            .change-password-modal .form-group {
                margin: 0 0 24px 0;
                height: 36px;
            }

            .change-password-modal .modal-footer {
                border-top: 0;
                padding: 0;
                height: 56px;
                position: relative;
            }

            .change-password-modal .modal-footer .btn-secondary,.modal-footer .alter-password-submit {
                position: absolute;
                height: 32px;
                width: 66px;
                border-radius: 16px;
                font-size: 13px;
                color: #555555;
                top: 0;
                left: 50%;
                background-color: #f7f7f7;
                border: 1px solid #f7f7f7;
            }

            .change-password-modal .modal-footer .alter-password-submit {
                left: 35%;
                color: #fff;
                background-color: #3399ff;
                border: 1px solid #3399ff;
            }

            main.container .main-r {
                max-width: 100%;
            }

            main.container .main-r-content {
                padding: 0;
                border-color: #fff;
                border-radius: 8px;
            }

            .pagination {
                justify-content: center;
            }

            .pagination .disabled span,.pagination li span,.pagination li a{
                margin: 0 1.5px;
                height: 32px;
                width: 32px;
                color: #555555;
                border-radius: 4px;
                text-decoration: none;
                border: 0;
            }

            .pagination li {
                border: 1px solid #f7f7f7;
            }

            .pagination li:first-of-type {
                margin-right: 11px;
            }

            .pagination li:last-of-type {
                margin-left: 11px;
            }

            .pagination .active span{
                background-color: #3399ff;
                border: 1px solid #3399ff;
                color: #fff;
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="container nav-top">
                <a class="navbar-brand" href="">
                    <?php if(!empty($option['logo'])): ?>
                    <img src="<?php echo $option['logo']; ?>" style="height: 30px;display: inline-block">
                    <?php else: ?>
                    <img src="__image__/platform/logo.png" style="height: 30px;display: inline-block">
                    <?php endif; ?>
                </a>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"
                           href="http://example.com"
                           id="dropdown01"
                           data-toggle="dropdown"
                           aria-haspopup="true"
                           aria-expanded="false">
                            <i class="iconfont icon-person" style="font-size: 1.3rem;line-height: 1;vertical-align: middle"></i>
                            <span><?php echo $admin['username']; ?></span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdown01">
                            <a class="dropdown-item alter-password" href="javascript:" data-toggle="modal"
                               data-target="#alterPassword">修改密码</a>
                            <a class="dropdown-item" href="<?php echo url('passport/logout'); ?>">注销</a>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="container nav-text">管理中心</div>
            <div class="container nav-menu">
                <ul style="list-style: none;margin: 0;padding: 0 10px;">
                    <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo): ?>
                        <li class="menu-item" data-url="<?php echo $vo['route']; ?>"><?php echo $vo['name']; ?></li>
                        <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
        </nav>
        <main role="main" class="container">
            <div>
                <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo): ?>
                        <div class="child-menu" data-url="<?php echo $vo['route']; ?>">
                            <?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$i): $mod = ($i % 2 );++$i;?>
                                <a class="<?php if($route == $i['route']): ?>active<?php endif; ?>" href="<?php echo url($i['route']); ?>">
                                    <span><?php echo $i['name']; ?></span>
                                </a>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    <?php endif; endforeach; endif; else: echo "" ;endif; ?>                
            </div>
            <div class="main-r">
                <div class="main-r-content">
                    <style>
    .subapp-search {
        width: 196px;
        height: 54px;
        padding-left: 16px;
        position: relative;
    }

    .subapp-search input{
        margin-top: 12px;
        width: 180px!important;
        height: 30px;
        border-radius: 15px;
        padding-left: 12px;
    }

    .subapp-search .btn {
        position: absolute;
        height: 14px;
        width: 14px;
        padding: 0;
        line-height: normal;
        top: 20px;
        border: 0;
        right: 12px;
    }

    .subapp-search .btn img {
        height: 14px;
        width: 14px;
    }

    .subapp-list {
        border: 0;
        border-top: 1px solid #f7f7f7;
    }

    .subapp-list thead, .subapp-list thead tr{
        border: 0;
    }

    .subapp-list thead th {
        background-color: #fff;
        height: 40px;
        border: 0;
    }

    .subapp-list tbody td {
        height: 76px;
        line-height: 76px;
        padding-top: 0;
        padding-bottom: 0;
        border-top: 1px solid #f7f7f7;
    }

    .operate a {
        margin-top: 12px;
        display: inline-block;
        height: 32px;
        width: 32px;
        border-radius: 16px;
        background-color: #f5f5f5;
        margin-right: 10px;
    }

    .operate a img {
        display: block;
        margin: 6px;
        height: 20px;
        width: 20px;
    }

    .add-app {
        display: inline-block;
        padding: 0;
        height: 32px;
        line-height: 32px;
        width: 104px;
        border-radius: 16px;
        font-size: 13px;
        color: #fff;
        background-color: #3399ff;
        border: 1px solid #3399ff;
    }

    .add-modal .modal-dialog .modal-content{
        width: 600px;
    }

    .add-modal .form-input {
        width: 300px;
    }

    .add-modal .modal-body {
        padding: 0
    }

    .add-modal .modal-dialog {
        margin-top: 5%;
    }

    .search{
        display: inline-block;
        border-radius:15px;
    }
    .search input{
        border-radius:15px;
        width: 180px!important;
        height: 30px;
        padding-left: 12px;
    }
</style>
<div class="subapp-search">
    <form method="get" class="form-inline">
        <input type="hidden" name="r" value="admin/app/other-app">
        <input value="<?php echo $keyword; ?>" placeholder="名称/账户" type="text" name="keyword"
               class="form-control form-control-sm">
        <button style="cursor: pointer" class="btn btn-link btn-sm"><img src="__image__/admin/A/search.png" alt=""></button>
    </form>
</div>
<div class="modal add-modal fade" id="add-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title" id="myModalLabel"><b>添加客服系统</b></div>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="add-modal-body modal-body"></div>
        </div>
    </div>
</div>
<table class="subapp-list table bg-white">
    <thead>
    <tr style="font-size: 13px;color: #555555">
        <th></th>
        <th>ID</th>
        <th>账户</th>
        <th>名称</th>
        <th>状态</th>
        <th>操作</th>
    </tr>
    </thead>
    <?php if(count($list) == 0): ?>
    <tr>
        <td colspan="5" class="text-center p-5">
            <!--<a href="javascript:" class="add-app">添加客服系统商城</a>-->
            <span class="text-muted">暂无相关客服系统</>
        </td>
    </tr>
    <?php endif; if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
    <col style="width: 32px">
    <col style="width: 94px">
    <col style="width: 208px">
    <col style="width: 220px">
    <col style="width: 164px">
    <col>
    <tr>
        <td></td>
        <td><?php echo $item['id']; ?></td>
        <td><?php echo $item['admin']['username']; ?></td>
        <td>
            <?php if($item['is_recycle'] == 0): ?>
            <a style="color: #3399ff;text-decoration: none;" href="<?php echo url('app/entry', ['id' => $item['id']]); ?>"><?php echo $item['business_name']; ?></a>
            <?php else: ?>
            <?php echo $item['business_name']; endif; ?>
        </td>
        <td>
            <?php echo !empty($item['is_recycle']) && $item['is_recycle']==1?'回收站': '正常'; ?>
        </td>
        <td class="operate">
            <a href="#" data-toggle="modal" class="edit-app" id="<?php echo url('platform/app/edit', ['id' => $item['id']]); ?>" data-target="#add-modal"><img src="__image__/admin/A/edit.png" alt="编辑"></a>
            <?php if($item['is_recycle'] == 0): ?>
            <a class="recycle-btn"
               data-desc="确认将客服系统放进回收站？"
               href="<?php echo url('app/setRecycle', ['id' => $item['id'],'action'=>1]); ?>"><img src="__image__/admin/A/restore.png" alt=""></a>
            <?php else: ?>
            <a class="recycle-btn"
               data-desc="确认恢复客服系统？"
               href="<?php echo url('app/setRecycle', ['id' => $item['id'],'action'=>0]); ?>"><img src="__image__/admin/A/recover.png" alt=""></a>
            <?php endif; ?>
            <a class="delete-btn" href="<?php echo url('app/delete', ['id' => $item['id']]); ?>"><img src="__image__/admin/A/delete.png" alt=""></a>
        </td>
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<?php echo $page; ?>
<script>
    $(document).on("click", ".delete-btn", function () {
        var href = $(this).attr("href");
        $.myConfirm({
            content: "确认将客服系统删除？请谨慎操作",
            confirm: function () {
                $.myLoading({
                    title: "正在提交",
                });
                $.ajax({
                    url: href,
                    dataType: "json",
                    success: function (res) {
                        $.myLoadingHide();
                        $.myToast({
                            content: res.msg,
                            callback: function () {
                                location.reload();
                            }
                        });
                    }
                });

            }
        });
        return false;
    });

    $(document).on("click", ".recycle-btn", function () {
        var href = $(this).attr("href");
        var desc = $(this).attr("data-desc");
        $.myConfirm({
            content: desc,
            confirm: function () {
                $.myLoading({
                    title: "正在提交",
                });
                $.ajax({
                    url: href,
                    dataType: "json",
                    success: function (res) {
                        $.myLoadingHide();
                        $.myToast({
                            content: res.msg,
                            callback: function () {
                                location.reload();
                            }
                        });
                    }
                });
            }
        });
        return false;
    });

    $(document).on("click", ".edit-app", function () {
        let id = this.id;
        $('.add-modal').find('.modal-title').text('编辑客服系统')
        $.ajax({
            url: id,
            success: function (data) {
                var result = $(data);
                $(".add-modal-body").html(result);
            }
        })
    });
</script>
                </div>
            </div>

        </main><!-- /.container -->
        <footer>
            <?php if(!empty($option['copyright']) || $option['copyright'] != ''): ?>
            <div class="text-center copyright p-4">
                <?php echo $option['copyright']; ?>
            </div>
            <?php else: ?>
            <div class="text-center copyright p-4" style="color: #999;font-size: 16px">Powered by 禾匠信息科技</div>
            <?php endif; ?>
        </footer>

        <!-- Modal -->
        <div class="modal fade change-password-modal" id="alterPassword" data-backdrop="static" tabindex="-1" role="dialog"
             aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title" id="exampleModalLabel">修改密码</div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" class="auto-submit-form alter-password-form">
                            <div class="form-group">
                                <label class="col-form-label required">原密码</label>
                                <div class="form-input">
                                    <input type="password" name="old_password" class="form-control"
                                           placeholder="您当前的密码">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label required">新密码</label>
                                <div class="form-input">
                                    <input type="password" name="new_password" class="form-control new-password-1"
                                           placeholder="要设置的新密码">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label required check">确认密码</label>
                                <div class="form-input">
                                    <input type="password" class="form-control new-password-2" placeholder="再次输入新密码">
                                </div>
                            </div>
                            <div class="form-error alert alert-danger" style="display: none">aaaaaa</div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="button" class="btn btn-primary alter-password-submit">提交</button>
                    </div>
                </div>
            </div>
        </div>
        <!--无用、防止报错 start-->
        <div id="file" hidden></div>
        <div id="district_pick_modal" hidden></div>
        <!--end-->
        <script>
            $(function(){
                $(".child-menu").find('.active').parent().show();
                let url = $(".child-menu").find('.active').parent()[0].dataset.url;     
                let first_url = $(".menu-item")[0].dataset.url;
                let sec_url = $(".menu-item")[1].dataset.url;
                let thrid_url = $(".menu-item")[2].dataset.url;
                if(url == first_url) {
                    $(".menu-item").first().addClass('active');
                }else if (url == thrid_url) {
                    $(".menu-item").last().addClass('active');
                }else if (url == sec_url) {
                    $(".menu-item:first").next().addClass('active');
                }
            }),

            $(document).on("click", ".menu-item", function () {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                let url = $(this)[0].dataset.url;
                let first_url = $(".child-menu")[0].dataset.url;
                let sec_url = $(".child-menu")[1].dataset.url;
                let thrid_url = $(".child-menu")[2].dataset.url;
                if(url == first_url) {
                    $(".child-menu").first().show();
                    $(".child-menu").first().siblings().hide();
                    $(".child-menu").first().find('a')[0].click();
                }else if (url == thrid_url) {
                    $(".child-menu").last().show();
                    $(".child-menu").last().siblings().hide();
                    $(".child-menu").last().find('a')[0].click();
                }else if (url == sec_url) {
                    $(".child-menu:first").next().show();
                    $(".child-menu:first").next().siblings().hide();
                    $(".child-menu:first").next().find('a')[0].click();
                }
            });

            $(document).on("click", ".alter-password-submit", function () {
                var new_password_1 = $(".alter-password-form .new-password-1").val();
                var new_password_2 = $(".alter-password-form .new-password-2").val();
                var error = $(".alter-password-form .form-error");
                var btn = $(this);
                if (new_password_1 !== new_password_2) {
                    error.html("新密码与确认密码不一致，请重新输入").show();
                    return false;
                }
                error.hide();
                btn.btnLoading();
                $.ajax({
                    url: "<?php echo url('passport/modifyPassword'); ?>",
                    type: "post",
                    dataType: "json",
                    data: $(".alter-password-form").serialize(),
                    success: function (res) {
                        if (res.code == 0) {
                            $("#alterPassword").modal("hide");
                            $.myAlert({
                                content: res.msg,
                                confirm: function () {
                                    location.reload();
                                }
                            });
                        } else {
                            error.html(res.msg).show();
                            btn.btnReset();
                        }
                    }
                });
            });
        </script>
        
    </body>
</html>