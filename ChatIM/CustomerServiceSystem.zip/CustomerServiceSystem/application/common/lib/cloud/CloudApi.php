<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2019/3/11
 * Time: 16:28
 */
namespace app\common\lib\cloud;

class CloudApi
{
    const BASE_URL = 'https://auth.zjhejiang.com';
    const SITE_INFO = '/cs/site/info';
    const SITE_UPDATE = '/cs/update/index';
}
