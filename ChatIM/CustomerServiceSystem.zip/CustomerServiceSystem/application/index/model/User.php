<?php
/**
 * Handler File Class
 *
 * @author liliang <liliang@wolive.cc>
 * @email liliang@wolive.cc
 * @date 2017/06/01
 */

namespace app\index\model;

use think\Model;
use traits\model\SoftDelete;

/**
 * 数据模型类.
 */
class User extends Model
{

}
