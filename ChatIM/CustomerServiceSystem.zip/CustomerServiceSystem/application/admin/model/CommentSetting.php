<?php
/**
 * @copyright ©2019 辰光PHP客服系统
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2019/5/9
 * Time: 10:04
 */

namespace app\admin\model;

use think\Model;

class CommentSetting extends Model
{
    protected $table = 'wolive_comment_setting';

}