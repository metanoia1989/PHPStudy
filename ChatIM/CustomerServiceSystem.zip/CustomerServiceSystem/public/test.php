<?php

var_dump("" == NULL);