
             
             /**
              *
              * wolive 标准窗口,js代码
              * 
              */
             
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
                link.type='text/css';
                link.rel = 'stylesheet';
                link.href ='http://customerservice.test/assets/css/index/dianqilai_online.css';
                head.appendChild(link);

            var dianqilai ={
                 visiter_id:'',
                 visiter_name:'',
                 avatar:'',
                 product:'',
                 open:function(){
                    var d =document.getElementById('wolive-box');
                    if(!d){
                      var div =document.createElement('div');
                      div.id ='dianqilai-kefu';
                      div.className +='dianqilai-form';
                      document.body.appendChild(div);
                      var w =document.getElementById('dianqilai-kefu');
                      w.innerHTML=' <i class="dianqilai-icon"></i><p class="dianqilai-item" onclick="dianqilai.blank(0)" >在线咨询</p>';
                    }

                 },
                 blank:function(groupid){

                

                  var web =encodeURI('http://customerservice.test/index/index/home?visiter_id='+this.visiter_id+'&visiter_name='+this.visiter_name+'&avatar='+this.avatar+'&business_id=1&groupid='+groupid+'&product='+this.product);
                      
                  var moblieweb = encodeURI('http://customerservice.test/mobile/index/home?visiter_id='+this.visiter_id+'&visiter_name='+this.visiter_name+'&avatar='+this.avatar+'&business_id=1&groupid='+groupid+'&product='+this.product);

                   if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
                     window.open(moblieweb); 
                   }else{
                     window.open(web); 
                   }
                 },
            }

            window.onload = dianqilai.open();
        